export class Notification {
  id: number;
  subject: string;
  description: string;
  isRead: boolean;
  createdBy: string;
  createdDate: Date;
}
