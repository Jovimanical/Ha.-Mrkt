import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-personal-information',
  templateUrl: './system-personal-information.component.html',
  styleUrls: ['./system-personal-information.component.scss']
})
export class SystemPersonalInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
