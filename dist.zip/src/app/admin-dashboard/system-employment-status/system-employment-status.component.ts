import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-employment-status',
  templateUrl: './system-employment-status.component.html',
  styleUrls: ['./system-employment-status.component.scss']
})
export class SystemEmploymentStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
