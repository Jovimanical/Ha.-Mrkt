import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-listings',
  templateUrl: './system-listings.component.html',
  styleUrls: ['./system-listings.component.scss']
})
export class SystemListingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
