import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-transaction-history',
  templateUrl: './system-transaction-history.component.html',
  styleUrls: ['./system-transaction-history.component.scss']
})
export class SystemTransactionHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
