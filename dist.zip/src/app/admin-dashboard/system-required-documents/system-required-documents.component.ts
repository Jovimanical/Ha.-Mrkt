import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-required-documents',
  templateUrl: './system-required-documents.component.html',
  styleUrls: ['./system-required-documents.component.scss']
})
export class SystemRequiredDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
