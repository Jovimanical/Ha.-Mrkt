export class Verification {
  email: string;
  code: string;
}
