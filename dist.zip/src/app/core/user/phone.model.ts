export class Phone {
  phoneNumber: string;
  phoneType: string;
}
