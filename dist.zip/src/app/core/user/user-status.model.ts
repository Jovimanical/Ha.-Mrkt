export class UserStatus {
  isActive: boolean;
  isVerifyRequired: boolean;
}
