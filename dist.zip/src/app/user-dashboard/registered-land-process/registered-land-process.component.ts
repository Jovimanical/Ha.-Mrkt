import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registered-land-process',
  templateUrl: './registered-land-process.component.html',
  styleUrls: ['./registered-land-process.component.scss']
})
export class RegisteredLandProcessComponent implements OnInit {
  public PageName = "Land Registeration Status";
  constructor() { }

  ngOnInit(): void {
  }

}
