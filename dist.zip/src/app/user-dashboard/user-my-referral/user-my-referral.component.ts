import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-my-referral',
  templateUrl: './user-my-referral.component.html',
  styleUrls: ['./user-my-referral.component.scss']
})
export class UserMyReferralComponent implements OnInit {
  public PageName = "Referrals"
  constructor() { }

  ngOnInit(): void {
  }

}
