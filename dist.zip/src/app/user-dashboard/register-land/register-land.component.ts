import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-land',
  templateUrl: './register-land.component.html',
  styleUrls: ['./register-land.component.scss']
})
export class RegisterLandComponent implements OnInit {
  public PageName = "Register your Land"
  constructor() { }

  ngOnInit(): void {
  }

}
