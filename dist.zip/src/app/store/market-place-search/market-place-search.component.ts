import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-place-search',
  templateUrl: './market-place-search.component.html',
  styleUrls: ['./market-place-search.component.scss']
})
export class MarketPlaceSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
