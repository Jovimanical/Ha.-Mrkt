import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-listings',
  templateUrl: './compare-listings.component.html',
  styleUrls: ['./compare-listings.component.scss']
})
export class CompareListingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
