import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-footer-menu',
  templateUrl: './dashboard-footer-menu.component.html',
  styleUrls: ['./dashboard-footer-menu.component.scss']
})
export class DashboardFooterMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
