export class Product {
  productId: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  sizes: string[];
}
