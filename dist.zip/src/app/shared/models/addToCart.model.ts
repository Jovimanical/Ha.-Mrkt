export class AddToCart {
  productId: number;
  size: string;
  quantity: number;
}
