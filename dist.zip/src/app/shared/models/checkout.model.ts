export class Checkout {
  name: string;
  email: string;
  company: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  zip: string;
}
