import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estate-loan-options',
  templateUrl: './estate-loan-options.component.html',
  styleUrls: ['./estate-loan-options.component.scss']
})
export class EstateLoanOptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
