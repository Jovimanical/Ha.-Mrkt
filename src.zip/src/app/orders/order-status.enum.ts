export enum OrderStatus {
  Processed = 1,
  InTransit = 2,
  Delivered = 3
}
