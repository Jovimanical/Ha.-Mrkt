export class Verification {
  code: string;
}
