export class ContactUs {
  name: string;
  email: string;
  phone: string;
  image: string;
}
