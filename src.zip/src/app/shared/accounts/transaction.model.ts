
export class Transaction {
  transactionId: string;
  accountId: string;
  accountName: string;
  date: string;
  type: string;
  description: string;
  amount: string;
  balance: string;
}
