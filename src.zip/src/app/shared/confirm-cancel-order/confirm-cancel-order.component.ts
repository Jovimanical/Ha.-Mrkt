import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-cancel-order',
  templateUrl: './confirm-cancel-order.component.html'
})
export class ConfirmCancelOrderComponent implements OnInit {

  constructor() { }

  ngOnInit() { }
}
