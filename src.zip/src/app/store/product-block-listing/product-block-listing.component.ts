import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-block-listing',
  templateUrl: './product-block-listing.component.html',
  styleUrls: ['./product-block-listing.component.scss']
})
export class ProductBlockListingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
