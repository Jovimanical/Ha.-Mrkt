export const environment = {
  production: false,
  API_URL: 'https://marketplace-house-africa.herokuapps.com/api/v1',
  SERVER_URL: 'https://marketplace-house-africa.herokuapps.com',
  MAPBOX_ACCESS_TOKEN:{
    accessToken: 'pk.eyJ1IjoibmV4dGVhcnRoIiwiYSI6ImNrcWF2YmVtcTBjaTIydmsxMnVvNmk3aGYifQ.mDtuHWG2eeALeo8b0PvK_w'
  },
  OAUTH_REDIRECT_URL: 'https://marketplace-house-africa.herokuapps.com/outh',
  OAUTH_CLIENT_ID: '',
  OAUTH_CLIENT_SECRET: ''
};
