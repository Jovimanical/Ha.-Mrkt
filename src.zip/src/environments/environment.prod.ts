export const environment = {
  production: true,
  API_URL: 'http://ec2-34-212-124-169.us-west-2.compute.amazonaws.com/api/v1',
  SERVER_URL: 'http://ec2-34-212-124-169.us-west-2.compute.amazonaws.com/api/v1',
  MAPBOX_ACCESS_TOKEN:{
    accessToken: 'pk.eyJ1IjoibmV4dGVhcnRoIiwiYSI6ImNrcWF2YmVtcTBjaTIydmsxMnVvNmk3aGYifQ.mDtuHWG2eeALeo8b0PvK_w'
  },
  OAUTH_REDIRECT_URL: 'http://ec2-34-212-124-169.us-west-2.compute.amazonaws.com/api/v1/oauth',
  OAUTH_CLIENT_ID: '',
  OAUTH_CLIENT_SECRET: ''
};
